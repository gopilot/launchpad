//
//  main.m
//  PilotDCProject
//
//  Created by Tony Lenzi on 3/29/14.
//  Copyright (c) 2014 Tacit Mobile. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TCTAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TCTAppDelegate class]));
    }
}
