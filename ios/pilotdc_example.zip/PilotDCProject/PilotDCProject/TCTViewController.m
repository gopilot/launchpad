//
//  TCTViewController.m
//  PilotDCProject
//
//  Created by Tony Lenzi on 3/29/14.
//  Copyright (c) 2014 Tacit Mobile. All rights reserved.
//

#import "TCTViewController.h"

@interface TCTViewController () <UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *teamTextField;
@property (weak, nonatomic) IBOutlet UITextView *teamListTextView;

@end

@implementation TCTViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	[self.teamTextField becomeFirstResponder];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)tappedOnView:(UITapGestureRecognizer *)sender {
    [self.teamTextField becomeFirstResponder];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    self.teamListTextView.text = [NSString stringWithFormat:@"%@\n%@",
                                  self.teamTextField.text,
                                  self.teamListTextView.text];
    
    self.teamTextField.text = @"";
    [self.teamTextField resignFirstResponder];
    return YES;
}

@end
